# Memoria del TFG — versión para Overleaf

Esta carpeta es la memoria preparada para compilar dentro del **plan gratuito de Overleaf**,
que corta el compilado a los pocos segundos. Sube la carpeta entera, abre `TFG.tex` y compila.

## Qué se ha cambiado respecto a la versión del repositorio

1. **Figuras ya rasterizadas.** Los diagramas que en el repositorio se dibujan con `tikz` y
   `pgfgantt` aquí son PDF ya generados (`figuras/fig_*.pdf`), y esos dos paquetes no se cargan.
2. **Bibliografía ya resuelta.** En lugar de `\bibliography{...}`, el documento hace
   `\input{bibliografia/bibliografia_resuelta}`, que contiene las 34 entradas ya formateadas por
   BibTeX. Así Overleaf no tiene que ejecutar BibTeX ni las dos pasadas adicionales que exige.

Las dos juntas bajan el compilado de unos 16 s a unos 5 s. El PDF resultante es el mismo:
106 páginas, mismo índice y misma bibliografía.

## Si añades o quitas una referencia

`bibliografia/bibliografia.bib` sigue aquí, pero **ya no se usa al compilar**. Para actualizar la
bibliografía, edita el `.bib` y regenera el fichero resuelto:

```
latexmk -pdf TFG.tex     # en una copia donde hayas restaurado \bibliography{bibliografia/bibliografia}
cp TFG.bbl bibliografia/bibliografia_resuelta.tex
```

O, más simple, compila la versión completa del repositorio (`memoria/`) y copia aquí su `TFG.bbl`.

## Si aun así se agota el tiempo

En Overleaf, menú izquierdo → *Compiler*, cambia **Normal** por **Fast [draft]**: reutiliza los
ficheros auxiliares y hace una sola pasada en vez de tres. Es lo normal mientras escribes; vuelve a
*Normal* para la versión final, porque sólo entonces se cuadran índices y referencias cruzadas.

## Pendientes

Las marcas `\completar{...}` (rojo) y `\verificar{...}` (naranja) señalan lo que falta por
rellenar o comprobar. Para listarlas: `grep -rn "completar{\|verificar{" capitulos TFG.tex`
