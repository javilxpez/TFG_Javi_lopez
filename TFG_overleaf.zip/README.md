# Memoria del TFG — version para Overleaf

Sube esta carpeta a Overleaf, abre `TFG.tex` y compila (pdfLaTeX). Esta preparada para caber
en el limite de tiempo del plan gratuito: compila en unos 5 s en vez de unos 17 s.

## Que la diferencia de la version del repositorio

1. **Diagramas ya rasterizados.** Los dibujos de `tikz` y `pgfgantt` son aqui PDF ya generados
   (`figuras/fig_*.pdf`), y esos dos paquetes no se cargan.
2. **Bibliografia ya resuelta.** En vez de `\bibliography{...}` hay un
   `\input{bibliografia/bibliografia_resuelta}` con las entradas ya formateadas, asi que Overleaf
   no ejecuta BibTeX ni las dos pasadas adicionales que exige.

El PDF resultante es el mismo: mismas paginas, mismo indice y misma bibliografia.

## Esta carpeta es generada: no la edites

Se crea con `python memoria/figuras/generar_overleaf.py` desde el repositorio. Escribe aqui, y
cualquier cambio que hagas en esta copia se perdera la proxima vez que la generes. **Edita siempre
`memoria/` en el repositorio** y vuelve a generar.

Eso incluye la bibliografia: `bibliografia/bibliografia.bib` viaja en el zip por comodidad, pero al
compilar no se usa. Para anadir una referencia, editala en el repositorio y regenera.

## Si aun asi se agota el tiempo

En Overleaf, menu izquierdo -> *Compiler*, cambia **Normal** por **Fast [draft]**: reutiliza los
ficheros auxiliares y hace una sola pasada. Vuelve a *Normal* para la version final, porque solo
entonces se cuadran indices y referencias cruzadas.

## Pendientes

Las marcas `\completar{...}` (rojo) y `\verificar{...}` (naranja) senalan lo que falta por
rellenar o comprobar. Para listarlas:

    grep -rn "completar{\|verificar{" capitulos TFG.tex
